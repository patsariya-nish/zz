package com.infosys.infytel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@EnableCircuitBreaker    //for using hystrix  This tells Spring Cloud that the application uses the Circuit Breaker pattern
@EnableDiscoveryClient
@SpringBootApplication
public class InfytelApplication {

	public static void main(String[] args) {
		SpringApplication.run(InfytelApplication.class, args);
	}
}
